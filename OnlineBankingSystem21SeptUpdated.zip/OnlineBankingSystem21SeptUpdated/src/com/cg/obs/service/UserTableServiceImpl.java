package com.cg.obs.service;

import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.obs.dao.UserTableDaoImpl;
import com.cg.obs.exception.BankException;

public class UserTableServiceImpl implements UserTableService{

	UserTableDaoImpl dao;
	public UserTableServiceImpl() {
		dao = new UserTableDaoImpl();
	}

	@Override
	public boolean validateLogin(int uId, String pwd) throws BankException {
		return dao.validateLogin(uId, pwd);
	}

	@Override
	public boolean resetPassword(int uId, String ques) throws BankException {
		return dao.resetPassword(uId, ques);
	}

	@Override
	public ArrayList<Long> getAccounts(int uId) throws BankException {
		return dao.getAccounts(uId);
	}

	@Override
	public boolean changePwd(int user_id, String newPwd) throws BankException {
		return dao.changePwd(user_id, newPwd);
	}

	@Override
	public boolean addUser(int uid,String custPwd, String custQues, String custTPwd, long accId) throws BankException {
		return dao.addUser(uid,custPwd, custQues, custTPwd, accId);
	}
	
	@Override
	public boolean validateUserId(int uId) throws BankException {
		String userId = new Integer(uId).toString();
		String uIdPattern = "[0-9]{6}";
		if(Pattern.matches(uIdPattern, userId))
		{
			return true;
		}
		else
		  {
			throw new BankException("UserId must contain only digits of length 8");
		  }
		
	}
	
	@Override
	public boolean validatePassword(String custPwd) throws BankException {
		String pwdPattern = "((?=.*\\d)(?=.*[a-z])(?=.*[@#$%]).{6,20})";
		if(Pattern.matches(pwdPattern, custPwd))
		{
			return true;
		}
		else
		  {
			throw new BankException("Passowrd must contain one digit, one lowercase letter and a special character with min length 6 and max length 20");
		  }
	}
	
	@Override
	public boolean confirmPassword(String custPwd, String confirmPwd) throws BankException{
		if(custPwd.equals(confirmPwd))
			return true;
		else
		  {
			throw new BankException("Password must be same");
		  }
	}

	@Override
	public boolean validateAdminLogin(String aId, String pwd) throws BankException {
		String adminId = "admin";
		String adminPwd = "admin";
		System.out.println(aId+"    "+pwd);
		if(adminId.equals(aId) && adminPwd.equals(pwd))
			return true;
		else 
			throw new BankException("AdminId or adminPassword is incorrect");
		
	}

	@Override
	public boolean validateOldPassword(int userId, String userPassword) throws BankException {
		return dao.validateOldPassword(userId, userPassword);
	}

	@Override
	public boolean validateSecurityQuestion(String secAns, int uId) throws BankException {
		
		return dao.validateSecurityQuestion(secAns, uId);
	}

	@Override
	public boolean validateForgotPassword(String forgotPwd) throws BankException {
		if(forgotPwd.equals("sbq500#"))
			return true;
		else
			throw new BankException("Password does not match");
	}

	@Override
	public boolean validateLockStatus(int uId) throws BankException {
		return dao.validateLockStatus(uId);
	}

	@Override
	public boolean validateTransPwd(long fromAccNo, String tranPwd)throws BankException {
		return dao.validateTransPwd(fromAccNo,tranPwd);
	}
}
