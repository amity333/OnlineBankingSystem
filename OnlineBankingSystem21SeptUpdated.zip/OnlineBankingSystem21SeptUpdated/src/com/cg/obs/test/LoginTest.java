package com.cg.obs.test;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.obs.dao.UserTableDaoImpl;
import com.cg.obs.exception.BankException;

import junit.framework.Assert;

public class LoginTest {
	
	static UserTableDaoImpl userDao = null;
	
	@BeforeClass
	public static void setUp()
	{
		userDao = new UserTableDaoImpl();

	}
	
	@AfterClass
	public static void atEnd()
	{
		System.out.println("Login function is tested successfully");
	}
	
	@Before
	public void befTest()
	{
		System.out.println("Test starts");
	}
	
	@After
	public void aftTest()
	{
		System.out.println("Test ends");
	}
	
	@Test
	public void loginValidateTestPass() throws BankException
	{
		try {
			Assert.assertEquals(true, userDao.validateLogin(100000, "nagul@123"));
		} catch (BankException e) {
			
			e.printStackTrace();
		}
	}
	
	@Test
	public void loginValidateTestFail() throws BankException
	{
		try {
			Assert.assertEquals(false, userDao.validateLogin(100000, "nagul@1234"));
		} catch (BankException e) {
			
			e.printStackTrace();
		}
	}
	
	
}
