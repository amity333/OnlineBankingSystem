package com.cg.obs.dao;

public interface QueryMapper
{
	public static final String LOGIN_VALIDATION="SELECT * FROM user_table WHERE user_Id=?";
	public static final String PASSWORD_VALIDATION="SELECT login_password FROM user_table WHERE user_Id=?";
	public static final String CREATE_ACCOUNT="INSERT INTO accountmaster VALUES(account_id.nextval,?,?,sysdate)";
	public static final String GET_CURR_ACCID="SELECT account_id.currval FROM DUAL";	
	public static final String CREATE_ACCOUNT_CUSTOMER="INSERT INTO customer VALUES(?,?,?,?,?,?)";	
	public static final String CREATE_ACCOUNT_USER_TABLE="INSERT INTO user_table VALUES(?,?,?,?,?,?)";
	public static final String SET_LOCK_STATUS="UPDATE user_table SET lock_status=? WHERE user_id=?";
	public static final String GET_LOCK_STATUS="SELECT lock_status FROM user_table WHERE user_id=?";
	public static final String DISPLAY_ALL_TRANSACTIONS="SELECT * FROM transactions WHERE dateoftransaction>=? and dateoftransaction<=? ORDER BY dateoftransaction DESC";
	public static final String DISPLAY_DAILY_TRANSACTIONS="select * from transactions where dateoftransaction=TO_DATE(?, 'yyyy-mm-dd')";
	public static final String GET_TODAY_TRANSACTIONS = "select tranamount from transactions where dateoftransaction=? and account_no=?";
	
	
	public static final String MINI_STATEMENT="SELECT * FROM (SELECT * FROM transactions WHERE account_no=? ORDER BY dateoftransaction DESC) WHERE rownum<=10";
	public static final String DETAILED_STATEMENT="SELECT * FROM transactions WHERE account_no=? and dateoftransaction>=TO_DATE(?, 'yyyy-mm-dd') and dateoftransaction<=TO_DATE(?, 'yyyy-mm-dd')";
	public static final String GET_DATA_FOR_UPDATE="SELECT address,mobile_num FROM transactions WHERE account_id=?";
	public static final String ADD_CHEQUE_REQUEST="INSERT INTO Service_Tracker VALUES(service_id.nextval,?,?,sysdate,?)";
	public static final String GET_SERVICE_STATUS="SELECT service_status FROM service_tracker WHERE service_id=?";
	public static final String GET_SERVICE_STATUS_BY_ACC="SELECT * FROM service_tracker WHERE account_id=?";
	public static final String GET_ACCOUNTS="SELECT account_id FROM user_table WHERE user_id=?";

	//Fund Transfer to self	
	public static final String ADD_TRANSFER="INSERT INTO fund_transfer VALUES(fund_transfer_id.nextval,?,?,?,?)";
	public static final String UPDATE_BALANCE="UPDATE accountmaster SET account_balance=? WHERE account_id=?";
	
	public static final String ADD_PAYEE="INSERT INTO payeetable VALUES(?,?,?)";
	public static final String GET_PAYEE="SELECT * FROM payeetable WHERE account_id=?";
	public static final String CHANGE_PWD="UPDATE user_table SET login_password=? WHERE user_id=?";
	public static final String RESET_PWD="SELECT secret_question FROM user_table WHERE user_id=?";
	public static final String GET_BALANCE = "SELECT account_balance FROM AccountMaster WHERE account_id=?";
	public static final String GET_PWD_BY_ID="SELECT transaction_password FROM user_table WHERE account_id=?";
	public static final String GET_PAYEE_BY_NAME="SELECT * FROM payeetable WHERE nick_name=?";
	public static final String FETCH_DATA="SELECT * FROM customer WHERE account_id=?";
	public static final String FETCH_ACCID="SELECT * FROM user_table WHERE user_id=?";
	public static final String GET_MOBILE="SELECT mobile_num FROM customer WHERE account_id=?";
	public static final String GET_ADDRESS="SELECT address FROM customer WHERE account_id=?";
	public static final String UPDATE_MOBILE="UPDATE customer SET mobile_num=? WHERE account_id=?";
	public static final String UPDATE_ADDRESS="UPDATE customer SET address=? WHERE account_id=?";
	public static final String ADD_TRANSACTION="INSERT INTO transactions VALUES(transaction_id.nextval,?,TO_DATE(?, 'yyyy-mm-dd'),?,?,?)";
	public static final String SECRET_QUESTION_VALIDATION="SELECT secret_question FROM user_table WHERE user_id=?";
	public static final String GET_SERVICE_STATUS_BY_REQ = "SELECT * FROM service_tracker WHERE account_id=? and service_id=?";
	public static final String GET_TRAN_PWD = "SELECT transaction_password FROM user_table WHERE account_id=?";
}
