package com.cg.obs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


import com.cg.obs.dto.AccountMaster;
import com.cg.obs.exception.BankException;
import com.cg.obs.util.DBUtil;


public class AccountMasterDaoImpl implements AccountMasterDao
{
	Logger accountLogger= null;
	Connection con;
	Statement st;
	PreparedStatement pst;
	CustomerDao cusDao;
	UserTableDao userDao;
	public AccountMasterDaoImpl() {
		super();
		accountLogger= Logger.getLogger(AccountMaster.class);
	    PropertyConfigurator.configure("log4j.properties");
		con=DBUtil.getconnection();
		cusDao=new CustomerDaoImpl();
		userDao=new UserTableDaoImpl();
	}
	@Override
	public boolean addAccount(int uid,String custName, String custEmail,
			String custAddr, String custPAN, String custPwd, String custQues,
			String custTPwd, String accType, long custMob, double balance) throws BankException {
		try {
			accountLogger.debug("Adding new account");
			pst=con.prepareStatement(QueryMapper.CREATE_ACCOUNT);
			pst.setString(1, accType);
			pst.setDouble(2, balance);
			long accId=0;
			int upd=pst.executeUpdate();
			if(upd>0)
			{
				st=con.createStatement();
				ResultSet rs=st.executeQuery(QueryMapper.GET_CURR_ACCID);
				while(rs.next())
				{
					accId=rs.getLong(1);
				}
			}
			else
			{
				return false;
			}
			cusDao.addCustomer(custName, custEmail, custAddr, custPAN, custMob, accId);
			userDao.addUser(uid,custPwd, custQues, custTPwd, accId);
		} catch (SQLException e) {
			throw new BankException(e.getMessage());
		}
		return true;
	}
	public ArrayList<AccountMaster> getBalance(long  uid) throws BankException {
		ArrayList<AccountMaster> al = new ArrayList<AccountMaster>();	
			try {
				accountLogger.debug("fetching account balance");
				long acc=0;
				ArrayList<Long> accIds=new ArrayList<Long>();
				PreparedStatement pst1=con.prepareStatement(QueryMapper.FETCH_ACCID);
				pst1.setLong(1, uid);
				ResultSet rs1=pst1.executeQuery();
				while(rs1.next()) {
					acc=rs1.getLong(1);
					accIds.add(acc);
				}
				for(long var:accIds)
				{
				pst=con.prepareStatement(QueryMapper.GET_BALANCE);
				pst.setLong(1, var);
				ResultSet rs=pst.executeQuery();
						while(rs.next())
						{
							int balance = rs.getInt(1);
							al.add(new AccountMaster(var, "", balance,null));
						}
						
						
				}
			} catch (SQLException e) {
				throw new BankException(e.getMessage());
			}
		
		return al;
	}
}
